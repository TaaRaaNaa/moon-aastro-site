# The Moon Aastro Guiide — Website

Website for **The Moon Aastro Guiide**, an astrology, numerology, Vastu &amp; healing
consultation practice run by **Vaishali Sharma**.

🔗 **Live site:** `https://<your-github-username>.github.io/<repo-name>/`
*(replace with your actual GitHub Pages URL once enabled — see below)*

---

## What's in this repo

| File / Folder        | Purpose                                                              |
|-----------------------|-----------------------------------------------------------------------|
| `index.html`          | Homepage — hero, about, services overview, free tools, lead magnet, testimonials, blog highlights, shop, FAQ, footer |
| `services.html`       | Full services page — detailed breakdown of all 5 readings, comparison table, FAQ |
| `assets/images/`      | Place for any local image assets (currently images are loaded from external URLs — see *Known limitations* below) |
| `_config.yml`         | GitHub Pages config (disables Jekyll theming since this is plain HTML/CSS/JS) |
| `.nojekyll`           | Tells GitHub Pages to skip Jekyll processing entirely |
| `README.md`           | This file |

This is a **static site** — plain HTML, CSS, and vanilla JavaScript, no build step,
no framework, no dependencies. Every page is fully self-contained (styles and scripts
are inline in each `.html` file).

---

## Services offered

1. **Astrology Reading** — Vedic astrology consultation; covers career, relationship,
   business timing, and year-ahead questions as specializations within one reading type
2. **Numerology** — Life Path, Expression, and Personal Year number reading
3. **Vastu Consultation** — home/workspace energy and layout assessment
4. **7 Chakra Healing** — guided energy-balancing session
5. **Tarot Card Reading** — focused reading for a specific question

## Contact details on file

- 📞 519-670-1325
- ✉ vaishalisharma.2354@gmail.com
- 📷 [@the_moon_aastro_guide](https://www.instagram.com/the_moon_aastro_guide)

If any of these change, search-and-replace across both `.html` files — see
*Updating contact info* below.

---

## How to view it locally

No server or build tools required. Either:

- Double-click `index.html` to open it directly in a browser, **or**
- From this folder, run a tiny local server (recommended, avoids some browser
  file:// quirks):

  ```bash
  python3 -m http.server 8000
  ```

  Then visit `http://localhost:8000` in your browser.

---

## How to publish it live (GitHub Pages)

1. Push this repo to GitHub (if you haven't already).
2. Go to your repo on GitHub → **Settings → Pages**.
3. Under **Build and deployment → Source**, choose **Deploy from a branch**.
4. Under **Branch**, choose `main` and folder `/ (root)`, then **Save**.
5. Wait about a minute. GitHub will show you the live URL at the top of that
   same Pages settings screen — typically:

   ```
   https://<your-username>.github.io/<repo-name>/
   ```

6. Every time you push a change to `main`, the live site updates automatically
   within a minute or two — no separate "deploy" step needed.

### Using a custom domain (optional, later)

Once you're happy with the GitHub Pages URL, you can point your own domain
(e.g. `themoonaastroguiide.com` or a subdomain like `new.themoonaastroguiide.com`)
at this repo instead:

1. In **Settings → Pages → Custom domain**, enter your domain.
2. Add the DNS records GitHub shows you (a `CNAME` record for a subdomain, or
   `A`/`ALIAS` records for an apex domain) at your domain registrar.
3. Wait for DNS to propagate (can take a few minutes to a few hours).

---

## How to update content later

Everything lives in two files — `index.html` and `services.html`. Both are plain
text, so any text editor works (VS Code, Notepad, even GitHub's own web editor).

**Quick edits directly on GitHub.com** (no local setup needed):
1. Open the file you want to change on GitHub.
2. Click the pencil ("Edit") icon.
3. Make your change, scroll down, and click **Commit changes**.
4. The live site updates automatically within a minute or two.

### Updating contact info
Search for the phone number, email, or Instagram handle in both `.html` files
and replace every instance — they currently appear in the footer of each page,
and the phone/email also appear as clickable `tel:` / `mailto:` links.

### Adding real booking, payments, or calculators
Right now these are placeholder destinations (they scroll to the relevant
section rather than performing real actions):
- The "Book a Reading" buttons → currently scroll to `#booking`
- The Free Tools calculators → currently scroll to the email signup (`#magnet`)
- The Shop product links → currently scroll to the Shop section

To make these fully functional, you'd integrate:
- **Calendly** (or similar) for real booking/scheduling
- **Stripe** or **PayPal** for payments
- Custom JS (or a third-party widget) for the actual astrology/numerology calculators
- **Mailchimp** or **HubSpot** for the email capture form to actually collect leads

### Adding a real blog or shop backend
The Blog and Shop sections currently show placeholder cards. For a real
content-managed blog or storefront, you'd either build dedicated pages per
post/product, or migrate those sections to a CMS/e-commerce platform and link
out to it from here.

---

## Known limitations (read before sharing widely)

- **Images load from an external URL** (Squarespace CDN) — if that link ever
  breaks, the About section portrait will disappear. Consider downloading the
  image and placing it in `assets/images/` instead, then updating the `<img src>`
  path in `index.html`.
- **No real backend** — the contact form, calculators, shop, and booking button
  are visual/navigational only; nothing is processed or stored.
- **Animations** — the background "orbiting planets" effect is pure CSS, tuned
  to run lighter on small/low-power screens and richer on high-end displays.
  If performance ever feels heavy on a specific device, the planet elements
  can be trimmed in the `.orbit-field` block at the top of each file's `<style>`.

---

## License

This site's code belongs to the site owner. No open-source license is applied.
